-- Create database (only if it does not exist)
CREATE DATABASE IF NOT EXISTS `mfm_schools` 
  DEFAULT CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci;

-- Select the database
USE `mfm_schools`;

-- ==============================
-- Admins Table
-- ==============================
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(120) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL, -- store hashed password
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ==============================
-- Students Table
-- ==============================
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(150) NOT NULL,
  `admission_no` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(120),
  `phone` VARCHAR(20),
  `gender` ENUM('Male','Female') NOT NULL,
  `dob` DATE,
  `class` VARCHAR(50),
  `passport` VARCHAR(255), -- file path
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ==============================
-- Applications Table
-- ==============================
DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(20),
  `gender` ENUM('Male','Female') NOT NULL,
  `dob` DATE,
  `address` TEXT,
  `class_applied` VARCHAR(50),
  `passport` VARCHAR(255),
  `status` ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ==============================
-- Results Table
-- ==============================
DROP TABLE IF EXISTS `results`;
CREATE TABLE `results` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `admission_no` VARCHAR(50) NOT NULL,
  `term` ENUM('1st Term','2nd Term','3rd Term') NOT NULL,
  `session` VARCHAR(20) NOT NULL,
  `class` VARCHAR(50) NOT NULL,
  `subject` VARCHAR(100) NOT NULL,
  `score` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_student` FOREIGN KEY (`student_id`) 
      REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ==============================
-- Insert Default Admin
-- ==============================
INSERT INTO `admins` (`name`, `email`, `password`) VALUES
('Super Admin', 'admin@mfm-schools.com', 
'$2y$10$wFhQzU7TqUoZzN3V1jC7OuhcKgAlp7xI6nHjdpV3wN95q8hXJh.Zu');
-- password = admin123
