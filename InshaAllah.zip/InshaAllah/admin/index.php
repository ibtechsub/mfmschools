<?php
// admin/index.php
session_start();

// ✅ If admin already logged in → redirect to dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: admin-dashboard.php");
    exit;
} else {
    // ❌ If not logged in → redirect to login page
    header("Location: login.php");
    exit;
}
?>
