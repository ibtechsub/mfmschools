<?php
// admin-dashboard.php
session_start();

// ✅ Temporary login check (replace later with real login system)
if (!isset($_SESSION['admin_logged_in'])) {
    // header("Location: login.php");
    // exit;
}

// Connect DB
include '../db.php';

// --- Mock data for now (replace with DB queries later) ---
$totalStudents = 120;
$totalResults  = 85;
$pendingApps   = 15;
$admins        = 2;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - MFM Standard Schools</title>
  <link rel="stylesheet" href="../style.css">
  <style>
    body {
      background: #f8fdf8;
      font-family: Arial, sans-serif;
    }
    .dashboard {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin: 30px auto;
      width: 90%;
    }
    .card {
      background: #fff;
      padding: 20px;
      border-radius: 12px;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      transition: transform 0.2s ease-in-out;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .card h2 {
      margin: 10px 0;
      color: #006400;
    }
    .card p {
      font-size: 1.1em;
      color: #444;
    }
    header {
      background: #006400;
      color: #fff;
      padding: 15px;
      text-align: center;
    }
    nav {
      background: #e8f5e9;
      padding: 10px;
      text-align: center;
    }
    nav a {
      margin: 0 15px;
      color: #006400;
      text-decoration: none;
      font-weight: bold;
    }
    nav a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <header>
    <h1>🎓 MFM Standard Schools - Admin Dashboard</h1>
  </header>

  <nav>
    <a href="results.php">➕ Add Result</a>
    <a href="results-list.php">📋 Manage Results</a>
    <a href="../students.php">👩‍🎓 Applications</a>
    <a href="logout.php">🚪 Logout</a>
  </nav>

  <div class="dashboard">
    <div class="card">
      <h2><?php echo $totalStudents; ?></h2>
      <p>Total Students</p>
    </div>
    <div class="card">
      <h2><?php echo $totalResults; ?></h2>
      <p>Results Uploaded</p>
    </div>
    <div class="card">
      <h2><?php echo $pendingApps; ?></h2>
      <p>Pending Applications</p>
    </div>
    <div class="card">
      <h2><?php echo $admins; ?></h2>
      <p>System Admins</p>
    </div>
  </div>
</body>
</html>
