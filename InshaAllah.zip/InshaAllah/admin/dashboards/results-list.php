<?php include 'db.php'; ?>
<?php
// results-list.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentName = $_POST['student_name'];
    $admissionNo = $_POST['admission_no'];
    $class = $_POST['class'];
    $term = $_POST['term'];
    $session = $_POST['session'];
    $subjects = $_POST['subjects'];
    $scores = $_POST['scores'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Results List</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="container">
    <h1>📋 Result for <?php echo htmlspecialchars($studentName); ?></h1>
    <p><strong>Admission No:</strong> <?php echo htmlspecialchars($admissionNo); ?></p>
    <p><strong>Class:</strong> <?php echo htmlspecialchars($class); ?></p>
    <p><strong>Term:</strong> <?php echo htmlspecialchars($term); ?></p>
    <p><strong>Session:</strong> <?php echo htmlspecialchars($session); ?></p>

    <table border="1" cellpadding="8" cellspacing="0" width="100%">
      <tr>
        <th>Subject</th>
        <th>Score</th>
      </tr>
      <?php foreach ($subjects as $index => $sub): ?>
      <tr>
        <td><?php echo htmlspecialchars($sub); ?></td>
        <td><?php echo htmlspecialchars($scores[$index]); ?></td>
      </tr>
      <?php endforeach; ?>
    </table>

    <br>
    <a href="results.php">➕ Add Another Result</a>
  </div>
</body>
</html>
