<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = $_POST;
    $photo = $_FILES['photo'];
    $photoPath = "uploads/" . basename($photo['name']);
    if (!is_dir("uploads")) mkdir("uploads");
    move_uploaded_file($photo['tmp_name'], $photoPath);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Applications - MFM Schools</title>
  <style>
    body {font-family:Arial, sans-serif; background:#f9f9f9; margin:0; padding:20px;}
    h2 {color:#2e7d32;}
    .card {background:#fff; padding:20px; border-radius:10px; box-shadow:0 2px 6px rgba(0,0,0,0.1); margin-bottom:20px;}
    img {max-width:150px; border-radius:10px; margin-top:10px;}
    .logout {float:right; background:#c62828; color:white; padding:8px 16px; border:none; border-radius:6px; text-decoration:none;}
  </style>
</head>
<body>
  <a href="logout.php" class="logout">Logout</a>
  <h2>Submitted Application</h2>

  <?php if (!empty($data)) { ?>
    <div class="card">
      <h3><?php echo htmlspecialchars($data['fullname']); ?></h3>
      <p><strong>DOB:</strong> <?php echo htmlspecialchars($data['dob']); ?></p>
      <p><strong>Gender:</strong> <?php echo htmlspecialchars($data['gender']); ?></p>
      <p><strong>Class:</strong> <?php echo htmlspecialchars($data['class']); ?></p>
      <p><strong>Address:</strong> <?php echo htmlspecialchars($data['address']); ?></p>
      <p><strong>Parent:</strong> <?php echo htmlspecialchars($data['parent_name']); ?> (<?php echo htmlspecialchars($data['parent_phone']); ?>)</p>
      <p><strong>Email:</strong> <?php echo htmlspecialchars($data['email']); ?></p>
      <p><strong>Previous School:</strong> <?php echo htmlspecialchars($data['prev_school']); ?></p>
      <p><strong>Last Class:</strong> <?php echo htmlspecialchars($data['last_class']); ?></p>
      <p><strong>Grades:</strong> <?php echo nl2br(htmlspecialchars($data['grades'])); ?></p>
      <p><strong>Passport Photo:</strong><br><img src="<?php echo $photoPath; ?>" alt="Passport Photo"></p>
    </div>
  <?php } else { ?>
    <p>No application submitted yet.</p>
  <?php } ?>
</body>
</html>
