<?php include 'db.php'; ?>
<?php
// results.php - Admin page to add results
session_start();
// Temporary login check (later we’ll connect to login.php)
if (!isset($_SESSION['admin_logged_in'])) {
    // header("Location: login.php");
    // exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Add Student Result</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="container">
    <h1>📊 Add Student Result</h1>

    <form action="results-list.php" method="post">
      <label>Student Name</label>
      <input type="text" name="student_name" required>

      <label>Admission Number</label>
      <input type="text" name="admission_no" required>

      <label>Class</label>
      <input type="text" name="class" required>

      <label>Term</label>
      <select name="term" required>
        <option value="1st Term">1st Term</option>
        <option value="2nd Term">2nd Term</option>
        <option value="3rd Term">3rd Term</option>
      </select>

      <label>Session</label>
      <input type="text" name="session" placeholder="2024/2025" required>

      <h3>Subjects & Scores</h3>
      <div class="subject-row">
        <input type="text" name="subjects[]" placeholder="Subject" required>
        <input type="number" name="scores[]" placeholder="Score" required>
      </div>

      <button type="button" onclick="addSubject()">+ Add More Subjects</button>

      <button type="submit">Save Result</button>
    </form>
  </div>

  <script>
    function addSubject() {
      const container = document.querySelector('.subject-row').parentNode;
      const newRow = document.createElement('div');
      newRow.classList.add('subject-row');
      newRow.innerHTML = `
        <input type="text" name="subjects[]" placeholder="Subject" required>
        <input type="number" name="scores[]" placeholder="Score" required>
      `;
      container.insertBefore(newRow, container.lastElementChild);
    }
  </script>
</body>
</html>
