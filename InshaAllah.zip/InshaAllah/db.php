<?php
// db.php - Database Connection

$host = "localhost";       // Database host (usually localhost)
$user = "root";            // Database username
$pass = "";                // Database password (leave empty for XAMPP default)
$dbname = "mfm_schools";   // Database name

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
} else {
    // echo "✅ Connected successfully"; // Uncomment for testing
}
?>
