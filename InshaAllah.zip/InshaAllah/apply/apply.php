<?php include 'db.php'; ?>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Apply - MFM Schools</title>
  <style>
    body {font-family: Arial, sans-serif; background:#f4fdf4; margin:0; padding:0;}
    .container {width:60%; margin:40px auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 4px 8px rgba(0,0,0,0.1);}
    h2 {text-align:center; color:#2e7d32;}
    .step {display:none;}
    .step.active {display:block;}
    .buttons {margin-top:20px; text-align:center;}
    button {padding:10px 20px; border:none; border-radius:6px; cursor:pointer; font-size:16px;}
    .next {background:#2e7d32; color:#fff;}
    .next:hover {background:#1b5e20;}
    .prev {background:#ccc;}
    .progressbar {display:flex; justify-content:space-between; margin:20px 0; counter-reset:step;}
    .progressbar li {list-style:none; width:100%; text-align:center; position:relative;}
    .progressbar li::before {content:counter(step); counter-increment:step; width:30px; height:30px; line-height:30px; border:2px solid #2e7d32; display:inline-block; border-radius:50%; background:white; color:#2e7d32;}
    .progressbar li.active::before {background:#2e7d32; color:white;}
    input, textarea, select {width:100%; padding:10px; margin:10px 0; border:1px solid #ccc; border-radius:6px;}
  </style>
</head>
<body>
  <div class="container">
    <h2>Student Application Form</h2>
    <ul class="progressbar">
      <li class="active">Personal</li>
      <li>Contact</li>
      <li>Academic</li>
      <li>Upload</li>
    </ul>

    <form action="students.php" method="POST" enctype="multipart/form-data">
      <!-- Step 1 -->
      <div class="step active">
        <input type="text" name="fullname" placeholder="Full Name" required>
        <input type="date" name="dob" required>
        <select name="gender" required>
          <option value="">Select Gender</option>
          <option>Male</option>
          <option>Female</option>
        </select>
        <input type="text" name="class" placeholder="Class Applying For" required>
      </div>

      <!-- Step 2 -->
      <div class="step">
        <textarea name="address" placeholder="Home Address" required></textarea>
        <input type="text" name="parent_name" placeholder="Parent/Guardian Name" required>
        <input type="tel" name="parent_phone" placeholder="Parent Phone" required>
        <input type="email" name="email" placeholder="Email" required>
      </div>

      <!-- Step 3 -->
      <div class="step">
        <input type="text" name="prev_school" placeholder="Previous School" required>
        <input type="text" name="last_class" placeholder="Last Class Completed" required>
        <textarea name="grades" placeholder="Grades/Results"></textarea>
      </div>

      <!-- Step 4 -->
      <div class="step">
        <label>Upload Passport Photo:</label>
        <input type="file" name="photo" accept="image/*" required>
      </div>

      <div class="buttons">
        <button type="button" class="prev" onclick="nextPrev(-1)">Previous</button>
        <button type="button" class="next" onclick="nextPrev(1)">Next</button>
        <button type="submit" class="next" style="display:none;">Submit</button>
      </div>
    </form>
  </div>

  <script>
    let currentStep = 0;
    const steps = document.querySelectorAll(".step");
    const progress = document.querySelectorAll(".progressbar li");
    const prevBtn = document.querySelector(".prev");
    const nextBtn = document.querySelector(".next");
    const submitBtn = document.querySelector("button[type=submit]");

    function showStep(n) {
      steps.forEach((step, i) => step.classList.toggle("active", i === n));
      progress.forEach((p, i) => p.classList.toggle("active", i <= n));
      prevBtn.style.display = n === 0 ? "none" : "inline-block";
      nextBtn.style.display = n === steps.length - 1 ? "none" : "inline-block";
      submitBtn.style.display = n === steps.length - 1 ? "inline-block" : "none";
    }

    function nextPrev(n) {
      currentStep += n;
      if (currentStep < 0) currentStep = 0;
      if (currentStep >= steps.length) currentStep = steps.length - 1;
      showStep(currentStep);
    }

    showStep(currentStep);
  </script>
</body>
</html>
