<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>MFM Schools</title>
  <style>
    body {font-family: Arial, sans-serif; margin:0; padding:0; background:#f9f9f9;}
    header {background:linear-gradient(135deg, #2e7d32, #66bb6a); color:white; padding:40px; text-align:center;}
    header h1 {margin:0; font-size:2.5em;}
    main {padding:40px; text-align:center;}
    .btn {background:#2e7d32; color:white; padding:15px 30px; border:none; border-radius:8px; font-size:18px; cursor:pointer;}
    .btn:hover {background:#1b5e20;}
  </style>
</head>
<body>
  <header>
    <h1>Welcome to MFM Schools</h1>
    <p>Building the future through quality education</p>
  </header>
  <main>
    <a href="apply.php"><button class="btn">Apply Now</button></a>
  </main>
</body>
</html>
