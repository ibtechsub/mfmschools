<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Result Checker - MFM Schools</title>
  <style>
    body {font-family:Arial, sans-serif; background:#f4fdf4; margin:0; padding:0;}
    .container {width:40%; margin:80px auto; background:#fff; padding:30px; border-radius:10px; box-shadow:0 4px 8px rgba(0,0,0,0.1);}
    h2 {text-align:center; color:#2e7d32;}
    input, select {width:100%; padding:12px; margin:10px 0; border:1px solid #ccc; border-radius:6px;}
    button {width:100%; padding:12px; background:#2e7d32; color:white; border:none; border-radius:6px; cursor:pointer; font-size:16px;}
    button:hover {background:#1b5e20;}
  </style>
</head>
<body>
  <div class="container">
    <h2>Check Your Result</h2>
    <form action="result-display.php" method="POST">
      <input type="text" name="adm_no" placeholder="Admission Number" required>
      <select name="term" required>
        <option value="">Select Term</option>
        <option>1st Term</option>
        <option>2nd Term</option>
        <option>3rd Term</option>
      </select>
      <select name="session" required>
        <option value="">Select Session</option>
        <option>2023/2024</option>
        <option>2024/2025</option>
      </select>
      <button type="submit">Check Result</button>
    </form>
  </div>
</body>
</html>
