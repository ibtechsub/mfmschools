<?php include 'db.php'; ?>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $adm_no = htmlspecialchars($_POST['adm_no']);
    $term = htmlspecialchars($_POST['term']);
    $session = htmlspecialchars($_POST['session']);
} else {
    header("Location: result-checker.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Result - MFM Schools</title>
  <style>
    body {font-family:Arial, sans-serif; background:#f9f9f9; margin:0; padding:20px;}
    .result-card {background:#fff; padding:20px; border-radius:10px; box-shadow:0 4px 8px rgba(0,0,0,0.1); width:70%; margin:auto;}
    h2, h3 {text-align:center; color:#2e7d32;}
    table {width:100%; border-collapse:collapse; margin:20px 0;}
    table, th, td {border:1px solid #ccc;}
    th, td {padding:10px; text-align:center;}
    th {background:#2e7d32; color:white;}
    .btn {display:block; text-align:center; margin:20px auto; padding:10px 20px; background:#2e7d32; color:white; border:none; border-radius:6px; cursor:pointer; text-decoration:none;}
    .btn:hover {background:#1b5e20;}
  </style>
</head>
<body>
  <div class="result-card">
    <h2>MFM Schools</h2>
    <h3>Result Slip</h3>
    <p><strong>Admission No:</strong> <?php echo $adm_no; ?></p>
    <p><strong>Term:</strong> <?php echo $term; ?></p>
    <p><strong>Session:</strong> <?php echo $session; ?></p>
    <hr>

    <table>
      <tr>
        <th>Subject</th>
        <th>CA (40)</th>
        <th>Exam (60)</th>
        <th>Total (100)</th>
        <th>Grade</th>
      </tr>
      <tr><td>Mathematics</td><td>35</td><td>55</td><td>90</td><td>A</td></tr>
      <tr><td>English</td><td>30</td><td>50</td><td>80</td><td>B</td></tr>
      <tr><td>Basic Science</td><td>28</td><td>50</td><td>78</td><td>B</td></tr>
      <tr><td>Social Studies</td><td>25</td><td>40</td><td>65</td><td>C</td></tr>
      <tr><td>Agricultural Science</td><td>32</td><td>45</td><td>77</td><td>B</td></tr>
    </table>

    <p><strong>Total Score:</strong> 390 / 500</p>
    <p><strong>Average:</strong> 78%</p>
    <p><strong>Position:</strong> 5th</p>

    <a href="#" class="btn">Download as PDF</a>
  </div>
</body>
</html>
