<?php
// index.php inside studentRegistration folder

// If you want to add future route/logic, you can do it here
// For now, we will simply include the student registration form
include("studentRegister.php");
?>
